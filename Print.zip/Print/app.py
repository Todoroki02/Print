from flask import Flask,render_template,url_for

app=Flask(__name__)

headings = ("ID", "FIRST NAME","SELECT","UPLOAD","PRINT","CAPTURE")
data=(
    ("1","Rolf"),
    ("2","Amy"),
    ("3","Bob"),
    ("4","Adam"),
    ("5","Helen"),
    ("6","Jen")
)

@app.route("/")
def component():
    return render_template("tables.html",headings=headings, data=data)

@app.route("/pdf")
def pdf():
    return render_template("pdf.html")

@app.route("/webcam")
def webcam():
    return render_template("webcam.html")




if __name__=="__main__":
    app.run(debug=True)