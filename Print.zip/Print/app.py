from flask import Flask,render_template,url_for

app=Flask(__name__)

headings = ("ID", "FIRST NAME","FILE NUMBER","UPLOAD","PRINT","CAPTURE")
data=(
    ("1","Praveen"),
    ("2","Sairam"),
    ("3","Shashank"),
    ("4","Vikas"),
    ("5","Kusum")
)

@app.route("/")
def component():
    return render_template("tables.html",headings=headings, data=data)

@app.route("/pdf")
def pdf():
    return render_template("pdf.html")

@app.route("/webcam")
def webcam():
    return render_template("webcam.html")




if __name__=="__main__":
    app.run(debug=True)